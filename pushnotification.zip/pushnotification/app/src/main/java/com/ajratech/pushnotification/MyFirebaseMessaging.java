package com.ajratech.pushnotification;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
public class MyFirebaseMessaging extends FirebaseMessagingService{
        private static final String TAG = "MyFirebaseMessaging";

        @Override
        public void onMessageReceived(RemoteMessage remoteMessage) {
            Log.d(TAG, "From: " + remoteMessage.getFrom());

            // Check if the message contains data payload
            if (remoteMessage.getData().size() > 0) {
                Log.d(TAG, "Message data payload: " + remoteMessage.getData());

                // Handle data payload here
                // You can extract values from remoteMessage.getData() and take appropriate actions
            }

            // Check if the message contains a notification payload
            if (remoteMessage.getNotification() != null) {
                Log.d(TAG, "Message Notification Body: " + remoteMessage.getNotification().getBody());

                // Handle notification payload here
                // You can show a notification or perform other UI-related actions
            }
        }

        @Override
        public void onNewToken(String token) {
            Log.d(TAG, "Refreshed token: " + token);

            // If you need to send the token to your server, do it here
            // You can also store the token locally for later use
        }
}
